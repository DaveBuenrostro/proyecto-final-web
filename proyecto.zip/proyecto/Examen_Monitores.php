<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/Examen_MonitoresStyle.css">
        <title>Examen Ventas - Productos (Monitores)</title>
    </head>
    <body>
        <div id="container">
            <div id="header">
                <div id="menu">
                    <div class="two-sections-left">
                        <button class="header-button"><a href="Examen_Inicio.php"><img src="img/LogoPC.jpg"></a></button><br>
                        <label id="logo-label">BestGuy</label>
                        <button class="header-button"><a href="Examen_Contactanos.php">Contactanos</a></button>
                        <button class="header-button"><a href="Examen_Computadoras.php">Computadoras</a></button>
                        <button class="header-button"><a href="Examen_Monitores.php">Monitores</a></button>
                        <button class="header-button"><a href="Examen_Perifericos.php">Perifericos</a></button>  
                    </div>
                    <div class="two-sections-right">
                        <?php
                        if(isset($_SESSION['id_usuario'])){
                            echo '<button class="header-button"><h4>'.$_SESSION['nombre'].'</h4></button>';
                        }else{
                        ?>
                            <button class="header-button"><a href="Examen_Login.php">Iniciar Sesion</a></button>
                            <button class="header-button"><a href="Examen_Registro.php">Registrarse</a></button>
                        <?php
                        }
                        ?>
                        <button class="header-button"><a href="Examen_Carrito.php"><img src="img/CarritoPC.jpg"></a></button>
                    </div>
                </div>
            </div>
            <div class="publicidad-productosMonitores">
                <img class="anuncioInicio-productosMonitores" src="img/inicio.PNG" alt="Anuncio">
            </div>

            <h1 class="inicio-productosMonitores">Monitores</h1>

            <div class="cuerpo-pagina-productosMonitores">
                <div class="producto1-cuerpopagina1-productosMonitores">
                    <img src="img2/monitor.jpg" alt="monitor">   
                    <h3 class="descripcion">Monitor Samsung</h3>
                    <h3 class="descripcion">$10000</h3>
                    <button class="boton-añadir1-productosMonitores">Añadir</button>
                </div>
                <div class="producto2-cuerpopagina1-productosMonitores">
                    <img src="img2/monitor2.jpg" alt="monitor">   
                    <h3 class="descripcion">Monitor HQ</h3>
                    <h3 class="descripcion">$9000</h3>
                    <button class="boton-añadir2-productosMonitores">Añadir</button>
                </div>
            </div>

            <div class="cuerpo-pagina2-productosMonitores">
                <div class="producto1-cuerpopagina2-productosMonitores">
                    <img src="img2/monitor3.jpg" alt="monitor">   
                    <h3 class="descripcion">Monitor Amazon</h3>
                    <h3 class="descripcion">$8000</h3>
                    <button class="boton-añadir3-productosMonitores">Añadir</button>
                </div>
                <div class="producto2-cuerpopagina2-productosMonitores">
                    <img src="img2/monitor4.jpg" alt="monitor">   
                    <h3 class="descripcion">Monitor Motorola</h3>
                    <h3 class="descripcion">$13000</h3>
                    <button class="boton-añadir4-productosMonitores">Añadir</button>
                </div>
            </div>
        </div>
    </body>
</html>