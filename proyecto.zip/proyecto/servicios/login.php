<?php
include('conexion.php');

$correo=$_POST['correo'];
$sql="select * from usuario where correo='$correo'";
$result=mysqli_query($conexion,$sql);
if($result){
    $row=mysqli_fetch_array($result);
    $count=mysqli_num_rows($result);
    if($count!=0){
        $password=$_POST['contrasena'];
        if($row['contrasena']!=$password){
            header('Location: ../Examen_Login.php?e=3');
        }else{
            session_start();
            $_SESSION['id_usuario']=$row['id_usuario'];
            $_SESSION['correo']=$row['correo'];
            $_SESSION['nombre']=$row['nombre'];
            header('Location: ../Examen_Inicio.php');
        }
    }else{
        header('Location: ../Examen_Login.php?e=2');
    }
}else{
    header('Location: ../Examen_Login.php?e=1');
}