<?php
include('../conexion.php');
$response=new stdClass();
$datos=[];
$i=0;

$sql="select * from producto";
$result=mysqli_query($conexion,$sql);
while($row=mysqli_fetch_array($result)){
    $obj=new stdClass();
    $obj->nombre=$row['nombre'];
    $obj->descripcion=$row['descripcion'];
    $obj->costo=$row['costo'];
    $obj->cantidad=$row['cantidad'];
    $obj->imagen_nombre=$row['imagen_nombre'];
    $datos[$i]=$obj;
    $i++;
}
$response->datos=$datos;

mysqli_close($conexion);
header('Content-Type: application/json');
echo json_encode($response);