<?php
include('conexion.php');

if(isset($_POST['registrar'])){
    if(strlen($_POST['nombre']) > 0 && strlen($_POST['nombre']) <=100){
        if(strlen($_POST['correo']) > 0 && strlen($_POST['correo']) <=100){
            if(strlen($_POST['contrasena']) > 0 && strlen($_POST['contrasena']) <=100){
                $nombre=trim($_POST['nombre']);
                $correo=trim($_POST['correo']);
                $contrasena=trim($_POST['contrasena']);
                $sql="INSERT INTO usuario(nombre, correo, contrasena) VALUES('$nombre','$correo','$contrasena')";
                $result=mysqli_query($conexion,$sql);
                if($result){
                    header('Location: ../Examen_Registro.php?e=5');
                }else{
                    header('Location: ../Examen_Registro.php?e=4');
                }
            }else{
                header('Location: ../Examen_Registro.php?e=3');
            }
        }else{
            header('Location: ../Examen_Registro.php?e=2');
        }
    }else{
        header('Location: ../Examen_Registro.php?e=1');
    }
}