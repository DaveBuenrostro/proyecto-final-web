CREATE TABLE Producto(
    id_producto int not null AUTO_INCREMENT,
    nombre varchar(50) not null,
    descripcion varchar(100) null,
    costo float not null,
    cantidad int not null,
    imagen_nombre varchar(100) not null,
    CONSTRAINT pk_producto
    PRIMARY KEY (id_producto)
);

INSERT INTO Producto(nombre,descripcion,costo,cantidad,imagen_nombre) 
VALUES  ('Audifonos Gamer','',1000,5,'periferico1.png'),
        ('PC Hype','',11000,4,'cpu1.png'),
        ('PC Revoke','',18000,3,'cpu2.png'),
        ('Monitor ASUS','',3000,4,'periferico5.png'),
        ('Monitor GameFactor','',2400,5,'periferico6.png'),
        ('Monitor LG','',1900,6,'periferico4.png');

CREATE TABLE Usuario(
    id_usuario int not null AUTO_INCREMENT,
    nombre varchar(100) not null,
    correo varchar(100) not null,
    contrasena varchar(100) not null,
    CONSTRAINT pk_usuario
    PRIMARY KEY (id_usuario)
);

INSERT INTO Usuario(nombre,correo,contrasena)
VALUES  ('Usuario','usertest@gmail.com','password123');