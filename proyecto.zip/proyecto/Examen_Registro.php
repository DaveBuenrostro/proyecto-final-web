<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/Examen_RegistroStyle.css">
        <title>Examen Ventas - Registro</title>
    </head>
    <body>
        <div id="container">
            <div id="header">
                <div id="menu">
                    <div class="two-sections-left">
                        <button class="header-button"><a href="Examen_Inicio.php"><img src="img/LogoPC.jpg"></a></button><br>
                        <label id="logo-label">BestGuy</label>
                        <button class="header-button"><a href="Examen_Contactanos.php">Contactanos</a></button>
                        <button class="header-button"><a href="Examen_Computadoras.php">Computadoras</a></button>
                        <button class="header-button"><a href="Examen_Monitores.php">Monitores</a></button>
                        <button class="header-button"><a href="Examen_Perifericos.php">Perifericos</a></button>  
                    </div>
                    <div class="two-sections-right">
                        <button class="header-button"><a href="Examen_Login.php">Iniciar Sesion</a></button>
                        <button class="header-button"><a href="Examen_Registro.php">Registrarse</a></button>
                        <button class="header-button"><a href="Examen_Carrito.php"><img src="img/CarritoPC.jpg"></a></button>
                    </div>
                </div>
            </div>
            <div class="content-registro">
             	<div class="divisiones-registro">
					<div class="posicion-registro">
						<form action="servicios/registro.php" method="POST" class="formulario-registro">
							<h3>Ingrese su Nombre</h3>
							<input type="text" name="nombre" placeholder="Nombre Completo">
							<h3>Ingrese su Email</h3>
							<input type="text" name="correo" placeholder="Correo electronico">
							<h3>Ingrese su Contraseña</h3>
							<input type="password" name="contrasena" placeholder="Contraseña">
                            <?php
                                if(isset($_GET['e'])){
                                    switch ($_GET['e']){
                                        case '1':
                                            echo '<p>Escribe un nombre de usuario</p>';
                                            break;
                                        case '2':
                                            echo '<p>Escribe un correo</p>';
                                            break;
                                        case '3':
                                            echo '<p>Escribe la contraseña</p>';
                                            break;
                                        case '4':
                                            echo '<p>Hubo un error en el registro!</p>';
                                            break;
                                        case '5':
                                            echo '<p>Registro exitoso! Ya puedes salir</p>';
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            ?>
							<div></div>
							<button name="registrar" class="btnCrearcuenta-registro">Registrarse</button>
							<p>Al crear una cuenta, aceptas las Condiciones de Uso y el Aviso de Privacidad de BestGuy.</p>
						</form>	
					</div>	
				</div>
			</div>
    </div>
    
</body>
</html>