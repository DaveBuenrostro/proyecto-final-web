<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/Examen_LoginStyle.css">
        <title>Examen Ventas - Login</title>
    </head>
    <body>
        <div id="container">
            <div id="header">
                <div id="menu">
                    <div class="two-sections-left">
                        <button class="header-button"><a href="Examen_Inicio.php"><img src="img/LogoPC.jpg"></a></button><br>
                        <label id="logo-label">BestGuy</label>
                        <button class="header-button"><a href="Examen_Contactanos.php">Contactanos</a></button>
                        <button class="header-button"><a href="Examen_Computadoras.php">Computadoras</a></button>
                        <button class="header-button"><a href="Examen_Monitores.php">Monitores</a></button>
                        <button class="header-button"><a href="Examen_Perifericos.php">Perifericos</a></button>  
                    </div>
                    <div class="two-sections-right">
                        <button class="header-button"><a href="Examen_Login.php">Iniciar Sesion</a></button>
                        <button class="header-button"><a href="Examen_Registro.php">Registrarse</a></button>
                        <button class="header-button"><a href="Examen_Carrito.php"><img src="img/CarritoPC.jpg"></a></button>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="divisiones-login">
                    <div class="posicion-login">
                        <form action="servicios/login.php" method="POST" class="formulario-login" >
                            <h3>Ingrese su Email</h3>
                            <input type="text" name="correo" placeholder="Correo electronico">
                            <h3>Ingrese su Contraseña</h3>
                            <input type="password" name="contrasena" placeholder="Contraseña">
                            <?php
                                if(isset($_GET['e'])){
                                    switch ($_GET['e']){
                                        case '1':
                                            echo '<p>Error de conexion</p>';
                                            break;
                                        case '2':
                                            echo '<p>Email invalido</p>';
                                            break;
                                        case '3':
                                            echo '<p>Contraseña incorrecta</p>';
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            ?>
                            <button class="btnEntrar-login">Ingresar</button>	
                            <div></div>
                            <button class="btnCrearcuenta-login">Registrarse</button>
                            <p>Bienvenido a BestGuy</p>	
                        </form>	
                    </div>	
                </div>
            </div>
        </div>
    </body>
</html>