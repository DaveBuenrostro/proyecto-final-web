<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/Examen_PerifericosStyle.css">
        <title>Examen Ventas - Productos (Perifericos)</title>
    </head>
    <body>
        <div id="container">
            <div id="header">
                <div id="menu">
                    <div class="two-sections-left">
                        <button class="header-button"><a href="Examen_Inicio.php"><img src="img/LogoPC.jpg"></a></button><br>
                        <label id="logo-label">BestGuy</label>
                        <button class="header-button"><a href="Examen_Contactanos.php">Contactanos</a></button>
                        <button class="header-button"><a href="Examen_Computadoras.php">Computadoras</a></button>
                        <button class="header-button"><a href="Examen_Monitores.php">Monitores</a></button>
                        <button class="header-button"><a href="Examen_Perifericos.php">Perifericos</a></button>  
                    </div>
                    <div class="two-sections-right">
                        <?php
                        if(isset($_SESSION['id_usuario'])){
                            echo '<button class="header-button"><h4>'.$_SESSION['nombre'].'</h4></button>';
                        }else{
                        ?>
                            <button class="header-button"><a href="Examen_Login.php">Iniciar Sesion</a></button>
                            <button class="header-button"><a href="Examen_Registro.php">Registrarse</a></button>
                        <?php
                        }
                        ?>
                        <button class="header-button"><a href="Examen_Carrito.php"><img src="img/CarritoPC.jpg"></a></button>
                    </div>
                </div>
            </div>
            <div class="publicidad-productosPerifericos">
                <img class="anuncioInicio-productosPerifericos" src="img/inicio.PNG" alt="Anuncio">
            </div>

            <h1 class="inicio-productosPerifericos">Perifericos</h1>

            <div class="cuerpo-pagina-productosPerifericos">
                <div class="producto1-cuerpopagina1-productosPerifericos">
                    <img src="img2/periferico1.png" alt="periferico">   
                    <h3 class="descripcion">Audifonos Gamer</h3>
                    <h3 class="descripcion">$7000</h3>
                    <button class="boton-añadir1-productosPerifericos">Añadir</button>
                </div>
                <div class="producto2-cuerpopagina1-productosPerifericos">
                    <img src="img2/periferico2.png" alt="periferico">   
                    <h3 class="descripcion">Audifonos Gamer</h3>
                    <h3 class="descripcion">$9000</h3>
                    <button class="boton-añadir2-productosPerifericos">Añadir</button>
                </div>
            </div>

            <div class="cuerpo-pagina2-productosPerifericos">
                <div class="producto1-cuerpopagina2-productosPerifericos">
                    <img src="img2/periferico3.png" alt="periferico">   
                    <h3 class="descripcion">Audifonos Gamer</h3>
                    <h3 class="descripcion">$5000</h3>
                    <button class="boton-añadir3-productosPerifericos">Añadir</button>
                </div>
                <div class="producto2-cuerpopagina2-productosPerifericos">
                    <img src="img2/img.jpg" alt="periferico">   
                    <h3 class="descripcion">Mouse</h3>
                    <h3 class="descripcion">$6000</h3>
                    <button class="boton-añadir4-productosPerifericos">Añadir</button>
                </div>
            </div>
        </div>
    </body>
</html>