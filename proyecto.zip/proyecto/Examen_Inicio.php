<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
        <link rel="stylesheet" href="css/Examen_InicioStyle.css">
        <title>Examen Ventas - Inicio</title>
    </head>
    <body>
        <div id="container">
            <div id="header">
                <div id="menu">
                    <div class="two-sections-left">
                        <button class="header-button"><a href="Examen_Inicio.php"><img src="img/LogoPC.jpg"></a></button><br>
                        <label id="logo-label">BestGuy</label>
                        <button class="header-button"><a href="Examen_Contactanos.php">Contactanos</a></button>
                        <button class="header-button"><a href="Examen_Computadoras.php">Computadoras</a></button>
                        <button class="header-button"><a href="Examen_Monitores.php">Monitores</a></button>
                        <button class="header-button"><a href="Examen_Perifericos.php">Perifericos</a></button>  
                    </div>
                    <div class="two-sections-right">
                        <?php
                        if(isset($_SESSION['id_usuario'])){
                            echo '<button class="header-button"><h4>'.$_SESSION['nombre'].'</h4></button>';
                        }else{
                        ?>
                            <button class="header-button"><a href="Examen_Login.php">Iniciar Sesion</a></button>
                            <button class="header-button"><a href="Examen_Registro.php">Registrarse</a></button>
                        <?php
                        }
                        ?>
                        <button class="header-button"><a href="Examen_Carrito.php"><img src="img/CarritoPC.jpg"></a></button>
                    </div>
                </div>
            </div>
            <div class="publicidad">
                <img class="anuncioInicio" src="img/inicio.PNG" alt="Anuncio">
            </div>
            <h1 class="inicio">Inicio</h1>
            <div class="cuerpo-pagina" id="space-list1">
            </div>
            <div class="cuerpo-pagina2" id="space-list2">
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function(){
                $.ajax({
                    url:'servicios/producto/get_all_productos.php',
                    type:'POST',
                    data:{},
                    success:function(data){
                        console.log(data);
                        let html1='';
                        for(var i=0; i<3; i++){
                            html1+=
                            '<div class="producto1-cuerpopagina1">'+
                                '<img src="img2/'+data.datos[i].imagen_nombre+'" alt="periferico">'+
                                '<h3 class="descripcion">'+data.datos[i].nombre+'</h3>'+
                                '<h3 class="descripcion">$'+data.datos[i].costo+'</h3>'+
                                '<button class="boton-añadir1">Añadir</button>'+
                            '</div>';
                        }
                        document.getElementById("space-list1").innerHTML=html1;
                        let html2='';
                        for(var i=3; i<6; i++){
                            html2+=
                            '<div class="producto1-cuerpopagina1">'+
                                '<img src="img2/'+data.datos[i].imagen_nombre+'" alt="periferico">'+
                                '<h3 class="descripcion">'+data.datos[i].nombre+'</h3>'+
                                '<h3 class="descripcion">$'+data.datos[i].costo+'</h3>'+
                                '<button class="boton-añadir1">Añadir</button>'+
                            '</div>';
                        }
                        document.getElementById("space-list2").innerHTML=html2;
                    },
                    error:function(err){
                        console.error(err);
                    }
                });
            });
        </script>
    </body>
</html>