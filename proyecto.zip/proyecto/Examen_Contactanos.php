<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/Examen_ContactanosStyle.css">
        <title>Examen Ventas - Contactanos</title>
    </head>
    <body>
        <div id="container">
            <div id="header">
                <div id="menu">
                    <div class="two-sections-left">
                        <button class="header-button"><a href="Examen_Inicio.php"><img src="img/LogoPC.jpg"></a></button><br>
                        <label id="logo-label">BestGuy</label>
                        <button class="header-button"><a href="Examen_Contactanos.php">Contactanos</a></button>
                        <button class="header-button"><a href="Examen_Computadoras.php">Computadoras</a></button>
                        <button class="header-button"><a href="Examen_Monitores.php">Monitores</a></button>
                        <button class="header-button"><a href="Examen_Perifericos.php">Perifericos</a></button>  
                    </div>
                    <div class="two-sections-right">
                        <?php
                        if(isset($_SESSION['id_usuario'])){
                            echo '<button class="header-button"><h4>'.$_SESSION['nombre'].'</h4></button>';
                        }else{
                        ?>
                            <button class="header-button"><a href="Examen_Login.php">Iniciar Sesion</a></button>
                            <button class="header-button"><a href="Examen_Registro.php">Registrarse</a></button>
                        <?php
                        }
                        ?>
                        <button class="header-button"><a href="Examen_Carrito.php"><img src="img/CarritoPC.jpg"></a></button>
                    </div>
                </div>
            </div>
            <div class="content">
                <div id="form">
                    <label id="form-label">Formulario de contacto</label><br>
                    <label class="input-label">Nombre completo:</label>
                    <input type="text" placeholder="Introduce aqui tu nombre completo"><br>
                    <label class="input-label">Correo electrónico:</label>
                    <input type="text" placeholder="Introduce aqui tu correo electronico"><br>
                    <label class="input-label">Número telefónico:</label>
                    <input type="text" placeholder="Introduce aqui tu numero telefonico"><br>
                    <label class="input-label">Mensaje:</label><br>
                    <textarea id="message-input" type="text" placeholder="Escribe tu mensaje"></textarea><br>
                    <button id="form-button"><a href="">Enviar</a></button>
                </div>
                <div id="info">
                    <label id="form-label">Informacion de contacto</label><br>
                    <label class="head-label">Ubicación:</label><br>
                    <label class="info-label">28 Jackson Blvd St 1020 Chicago IL 60604-2340</label><br>
                    <label class="head-label">Teléfonos:</label><br>
                    <label class="info-label">(+1)753-657-9417 </label><br>
                    <label class="info-label">(+1)771-961-5230</label><br>
                    <label class="head-label">Redes sociales:</label><br>
                    <button class="facebook-button"><a href=""><img src="img/LogoFB.png" title="Facebook"></a></button>
                    <button class="instagram-button"><a href=""><img src="img/LogoIG.jpg" title="Instagram"></a></button>
                </div>
            </div>
        </div>
    </body>
</html>